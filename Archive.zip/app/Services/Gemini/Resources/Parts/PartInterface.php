<?php

declare(strict_types=1);

namespace App\Services\Gemini\Resources\Parts;

interface PartInterface
{
}
